import Foundation

print("|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||")
print("|||||||||||||||||||||======1003. Inheritance======||||||||||||||||||||")
print("|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||")
print("===============================================================")
print("============1.Defining a Base Class==========")
print("===============================================================")
class Vehicle {
    var currentSpeed = 0.0
    var description: String {
        return "traveling at \(currentSpeed) miles per hour"
    }
    func makeNoise() -> String {
        // do nothing - an arbitrary vehicle doesn't necessarily make a noise
      ""
    }
}

let someVehicle = Vehicle()
"Vehicle: \(someVehicle.description)"
// Vehicle: traveling at 0.0 miles per hour
print("===============================================================")
print("============2.Subclassing==========")
print("===============================================================")
class Bicycle: Vehicle {
    var hasBasket = false
}

let bicycle = Bicycle()
bicycle.hasBasket = true
bicycle.currentSpeed = 15.0
"Bicycle: \(bicycle.description)"
// Bicycle: traveling at 15.0 miles per hour

class Tandem: Bicycle {
    var currentNumberOfPassengers = 0
}

let tandem = Tandem()
tandem.hasBasket = true
tandem.currentNumberOfPassengers = 2
tandem.currentSpeed = 22.0
"Tandem: \(tandem.description)"
// Tandem: traveling at 22.0 miles per hour
print("===============================================================")
print("============3.Overriding==========")
print("===============================================================")
This check ensures that your overriding definition is correct.
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
print("++++++a.Accessing Superclass Methods, Properties, and Subscripts++++")
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
print("++++++++++++++++b.Overriding Methods++++++++++++++")
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
class Train: Vehicle {
    override func makeNoise() -> String {
        "Choo Choo"
    }
}

let train = Train()
train.makeNoise()
// Prints "Choo Choo"
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
print("++++++++++++++++c.Overriding Properties++++++++++++++")
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
class Car: Vehicle {
    var gear = 1
    override var description: String {
        return super.description + " in gear \(gear)"
    }
}

let car = Car()
car.currentSpeed = 25.0
car.gear = 3
"Car: \(car.description)"
// Car: traveling at 25.0 miles per hour in gear 3

class AutomaticCar: Car {
    override var currentSpeed: Double {
        didSet {
            gear = Int(currentSpeed / 10.0) + 1
        }
    }
}

let automatic = AutomaticCar()
automatic.currentSpeed = 35.0
"AutomaticCar: \(automatic.description)"
// AutomaticCar: traveling at 35.0 miles per hour in gear 4
print("===============================================================")
print("============4.Preventing Overrides==========")
print("===============================================================")
