import Foundation

print("|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||")
print("|||||||||||||||||||||======1002. Initialization======||||||||||||||||||||")
print("|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||")
print("===============================================================")
print("============1.Setting Initial Values for Stored Properties==========")
print("===============================================================")
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
print("++++++++++++++++a.Initializers++++++++++++++")
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
struct Fahrenheit {
    var temperature: Double
    init() {
        temperature = 32.0
    }
}
var f = Fahrenheit()
"The default temperature is \(f.temperature)° Fahrenheit"
// Prints "The default temperature is 32.0° Fahrenheit"
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
print("++++++++++++++++b.Default Property Values++++++++++++++")
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
struct FahrenheitB {
    var temperature = 32.0
}
var fB = FahrenheitB()
"The default temperature is \(fB.temperature)° Fahrenheit"
print("===============================================================")
print("================2.Customizing Initialization==============")
print("===============================================================")
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
print("++++++++++++++++a.Initialization Parameters++++++++++++++")
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
struct Celsius {
    var temperatureInCelsius: Double
    init(fromFahrenheit fahrenheit: Double) {
        temperatureInCelsius = (fahrenheit - 32.0) / 1.8
    }
    init(fromKelvin kelvin: Double) {
        temperatureInCelsius = kelvin - 273.15
    }
}
let boilingPointOfWater = Celsius(fromFahrenheit: 212.0)
boilingPointOfWater.temperatureInCelsius
// boilingPointOfWater.temperatureInCelsius is 100.0
let freezingPointOfWater = Celsius(fromKelvin: 273.15)
freezingPointOfWater.temperatureInCelsius
// freezingPointOfWater.temperatureInCelsius is 0.0
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
print("++++++++++++++++b.Parameter Names and Argument Labels++++++++++++++")
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
struct Color {
    let red, green, blue: Double
    init(red: Double, green: Double, blue: Double) {
        self.red   = red
        self.green = green
        self.blue  = blue
    }
    init(white: Double) {
        red   = white
        green = white
        blue  = white
    }
}

let magenta = Color(red: 1.0, green: 0.0, blue: 1.0)
magenta
let halfGray = Color(white: 0.5)
halfGray
//let veryGreen = Color(0.0, 1.0, 0.0)
// this reports a compile-time error - argument labels are required
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
print("++++++++++++c.Initializer Parameters Without Argument Labels++++++++++")
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
struct CelsiusB {
    var temperatureInCelsius: Double
    init(fromFahrenheit fahrenheit: Double) {
        temperatureInCelsius = (fahrenheit - 32.0) / 1.8
    }
    init(fromKelvin kelvin: Double) {
        temperatureInCelsius = kelvin - 273.15
    }
    init(_ celsius: Double) {
        temperatureInCelsius = celsius
    }
}
let bodyTemperature = CelsiusB(37.0)
bodyTemperature.temperatureInCelsius
// bodyTemperature.temperatureInCelsius is 37.0
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
print("++++++++++++++++d.Optional Property Types++++++++++++++")
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
class SurveyQuestion {
    var text: String
    var response: String?
    init(text: String) {
        self.text = text
    }
    func ask() -> String {
        text
    }
}
let cheeseQuestion = SurveyQuestion(text: "Do you like cheese?")
cheeseQuestion.ask()
// Prints "Do you like cheese?"
cheeseQuestion.response = "Yes, I do like cheese."
cheeseQuestion.response
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
print("++++++++++e.Assigning Constant Properties During Initialization++++++++")
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
class SurveyQuestionB {
    let text: String
    var response: String?
    init(text: String) {
        self.text = text
    }
    func ask() -> String {
        text
    }
}
let beetsQuestionB = SurveyQuestionB(text: "How about beets?")
beetsQuestionB.ask()
// Prints "How about beets?"
beetsQuestionB.response = "I also like beets. (But not with cheese.)"
beetsQuestionB.response
print("===============================================================")
print("================3.Default Initializers==============")
print("===============================================================")
class ShoppingListItem {
    var name: String?
    var quantity = 1
    var purchased = false
}
var item = ShoppingListItem()
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
print("++++++++++++a.Memberwise Initializers for Structure Types++++++++++")
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
struct Size {
    var width = 0.0, height = 0.0
}

let twoByTwo = Size(width: 2.0, height: 2.0)
let zeroByTwo = Size(height: 2.0)
"\(zeroByTwo.width) \(zeroByTwo.height)"
// Prints "0.0 2.0"

let zeroByZero = Size()
"\(zeroByZero.width) \(zeroByZero.height)"
// Prints "0.0 0.0"
print("===============================================================")
print("================4.Initializer Delegation for Value Types==============")
print("===============================================================")
struct SizeB {
    var width = 0.0, height = 0.0
}
struct Point {
    var x = 0.0, y = 0.0
}
struct Rect {
    var origin = Point()
    var size = SizeB()
    init() {}
    init(origin: Point, size: SizeB) {
        self.origin = origin
        self.size = size
    }
    init(center: Point, size: SizeB) {
        let originX = center.x - (size.width / 2)
        let originY = center.y - (size.height / 2)
        self.init(origin: Point(x: originX, y: originY), size: size)
    }
}

let basicRect = Rect()
basicRect.origin
basicRect.size
// basicRect's origin is (0.0, 0.0) and its size is (0.0, 0.0)
let originRect = Rect(origin: Point(x: 2.0, y: 2.0),
    size: SizeB(width: 5.0, height: 5.0))
originRect.origin
originRect.size
// originRect's origin is (2.0, 2.0) and its size is (5.0, 5.0)
let centerRect = Rect(center: Point(x: 4.0, y: 4.0),
    size: SizeB(width: 3.0, height: 3.0))
centerRect.origin
centerRect.size
// centerRect's origin is (2.5, 2.5) and its size is (3.0, 3.0)
print("===============================================================")
print("================5.Class Inheritance and Initialization==============")
print("===============================================================")
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
print("++++++++++a.Designated Initializers and Convenience Initializers++++++++")
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
print("+++++++++++b.Syntax for Designated and Convenience Initializers+++++++++")
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
print("++++++++++++++++c.Initializer Delegation for Class Types++++++++++++++")
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
print("++++++++++++++++d.Two-Phase Initialization++++++++++++++")
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
print("++++++++++++++++e.Initializer Inheritance and Overriding++++++++++++++")
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
class Vehicle {
    var numberOfWheels = 0
    var description: String {
        return "\(numberOfWheels) wheel(s)"
    }
}

let vehicle = Vehicle()
"Vehicle: \(vehicle.description)"
// Vehicle: 0 wheel(s)

class Bicycle: Vehicle {
    override init() {
        super.init()
        numberOfWheels = 2
    }
}

let bicycle = Bicycle()
"Bicycle: \(bicycle.description)"
// Bicycle: 2 wheel(s)

class Hoverboard: Vehicle {
    var color: String
    init(color: String) {
        self.color = color
        // super.init() implicitly called here
    }
    override var description: String {
        return "\(super.description) in a beautiful \(color)"
    }
}

let hoverboard = Hoverboard(color: "silver")
"Hoverboard: \(hoverboard.description)"
// Hoverboard: 0 wheel(s) in a beautiful silver
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
print("++++++++++++++++f.Automatic Initializer Inheritance++++++++++++++")
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
print("++++++++++++g.Designated and Convenience Initializers in Action++++++++++")
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
class Food {
    var name: String
    init(name: String) {
        self.name = name
    }
    convenience init() {
        self.init(name: "[Unnamed]")
    }
}

let namedMeat = Food(name: "Bacon")
namedMeat.name
// namedMeat's name is "Bacon"
let mysteryMeat = Food()
mysteryMeat.name
// mysteryMeat's name is "[Unnamed]"

class RecipeIngredient: Food {
    var quantity: Int
    init(name: String, quantity: Int) {
        self.quantity = quantity
        super.init(name: name)
    }
    override convenience init(name: String) {
        self.init(name: name, quantity: 1)
    }
}

let oneMysteryItem = RecipeIngredient()
let oneBacon = RecipeIngredient(name: "Bacon")
let sixEggs = RecipeIngredient(name: "Eggs", quantity: 6)

class ShoppingListItemB: RecipeIngredient {
    var purchased = false
    var description: String {
        var output = "\(quantity) x \(name)"
        output += purchased ? " ✔" : " ✘"
        return output
    }
}

var breakfastList = [
    ShoppingListItemB(),
    ShoppingListItemB(name: "Bacon"),
    ShoppingListItemB(name: "Eggs", quantity: 6),
]
breakfastList[0].name = "Orange juice"
breakfastList[0].purchased = true
for item in breakfastList {
    print(item.description)
}
// 1 x Orange juice ✔
// 1 x Bacon ✘
// 6 x Eggs ✘
print("===============================================================")
print("================6.Failable Initializers==============")
print("===============================================================")
let wholeNumber: Double = 12345.0
let pi = 3.14159


if let valueMaintained = Int(exactly: wholeNumber) {
    "\(wholeNumber) conversion to Int maintains value of \(valueMaintained)"
}
// Prints "12345.0 conversion to Int maintains value of 12345"


let valueChanged = Int(exactly: pi)
// valueChanged is of type Int?, not Int


if valueChanged == nil {
    "\(pi) conversion to Int doesn't maintain value"
}
// Prints "3.14159 conversion to Int doesn't maintain value"
struct Animal {
    let species: String
    init?(species: String) {
        if species.isEmpty { return nil }
        self.species = species
    }
}

let someCreature = Animal(species: "Giraffe")
// someCreature is of type Animal?, not Animal

if let giraffe = someCreature {
    "An animal was initialized with a species of \(giraffe.species)"
}
// Prints "An animal was initialized with a species of Giraffe"
let anonymousCreature = Animal(species: "")
// anonymousCreature is of type Animal?, not Animal

if anonymousCreature == nil {
    "The anonymous creature couldn't be initialized"
}
// Prints "The anonymous creature couldn't be initialized"
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
print("++++++++++++++++a.Failable Initializers for Enumerations++++++++++++++")
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
enum TemperatureUnit {
    case kelvin, celsius, fahrenheit
    init?(symbol: Character) {
        switch symbol {
        case "K":
            self = .kelvin
        case "C":
            self = .celsius
        case "F":
            self = .fahrenheit
        default:
            return nil
        }
    }
}

let fahrenheitUnit = TemperatureUnit(symbol: "F")
if fahrenheitUnit != nil {
    "This is a defined temperature unit, so initialization succeeded."
}
// Prints "This is a defined temperature unit, so initialization succeeded."

let unknownUnit = TemperatureUnit(symbol: "X")
if unknownUnit == nil {
    "This isn't a defined temperature unit, so initialization failed."
}
// Prints "This isn't a defined temperature unit, so initialization failed."
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
print("++++++++b.Failable Initializers for Enumerations with Raw Values++++++")
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
enum TemperatureUnitB: Character {
    case kelvin = "K", celsius = "C", fahrenheit = "F"
}

let fahrenheitUnitB = TemperatureUnitB(rawValue: "F")
if fahrenheitUnitB != nil {
    "This is a defined temperature unit, so initialization succeeded."
}
// Prints "This is a defined temperature unit, so initialization succeeded."

let unknownUnitB = TemperatureUnitB(rawValue: "X")
if unknownUnitB == nil {
    "This isn't a defined temperature unit, so initialization failed."
}
// Prints "This isn't a defined temperature unit, so initialization failed."
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
print("++++++++c.Propagation of Initialization Failure++++++")
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
class Product {
    let name: String
    init?(name: String) {
        if name.isEmpty { return nil }
        self.name = name
    }
}

class CartItem: Product {
    let quantity: Int
    init?(name: String, quantity: Int) {
        if quantity < 1 { return nil }
        self.quantity = quantity
        super.init(name: name)
    }
}

if let twoSocks = CartItem(name: "sock", quantity: 2) {
    "Item: \(twoSocks.name), quantity: \(twoSocks.quantity)"
}
// Prints "Item: sock, quantity: 2"
if let zeroShirts = CartItem(name: "shirt", quantity: 0) {
    "Item: \(zeroShirts.name), quantity: \(zeroShirts.quantity)"
} else {
    "Unable to initialize zero shirts"
}
// Prints "Unable to initialize zero shirts"
if let oneUnnamed = CartItem(name: "", quantity: 1) {
    "Item: \(oneUnnamed.name), quantity: \(oneUnnamed.quantity)"
} else {
    "Unable to initialize one unnamed product"
}
// Prints "Unable to initialize one unnamed product"
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
print("++++++++++++++++c.Overriding a Failable Initializer++++++++++++++")
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
class Document {
    var name: String?
    // this initializer creates a document with a nil name value
    init() {}
    // this initializer creates a document with a nonempty name value
    init?(name: String) {
        if name.isEmpty { return nil }
        self.name = name
    }
}
class AutomaticallyNamedDocument: Document {
    override init() {
        super.init()
        self.name = "[Untitled]"
    }
    override init(name: String) {
        super.init()
        if name.isEmpty {
            self.name = "[Untitled]"
        } else {
            self.name = name
        }
    }
}
class UntitledDocument: Document {
    override init() {
        super.init(name: "[Untitled]")!
    }
}
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
print("++++++++++++++++d.The init! Failable Initializer++++++++++++++")
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
print("===============================================================")
print("================7.Required Initializers==============")
print("===============================================================")
print("===============================================================")
print("================8.Setting a Default Property Value with a Closure or Function==============")
print("===============================================================")
struct Chessboard {
    let boardColors: [Bool] = {
        var temporaryBoard: [Bool] = []
        var isBlack = false
        for i in 1...8 {
            for j in 1...8 {
                temporaryBoard.append(isBlack)
                isBlack = !isBlack
            }
            isBlack = !isBlack
        }
        return temporaryBoard
    }()
    func squareIsBlackAt(row: Int, column: Int) -> Bool {
        return boardColors[(row * 8) + column]
    }
}

let board = Chessboard()
board.squareIsBlackAt(row: 0, column: 1)
// Prints "true"
board.squareIsBlackAt(row: 7, column: 7)
// Prints "false"
