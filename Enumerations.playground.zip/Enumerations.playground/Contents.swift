import Foundation

print("|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||")
print("|||||||||||||||||||||======1004. Enumerations======||||||||||||||||||||")
print("|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||")

print("===============================================================")
print("============1.Enumeration Syntax==========")
print("===============================================================")

enum CompassPoint {
    case north
    case south
    case east
    case west
}

enum Planet {
    case mercury, venus, earth, mars, jupiter, saturn, uranus, neptune
}

var directionToHead = CompassPoint.west
directionToHead

directionToHead = .east
directionToHead
print("===============================================================")
print("============2.Matching Enumeration Values with a Switch Statement==========")
print("===============================================================")
directionToHead = .south
switch directionToHead {
case .north:
    "Lots of planets have a north"
case .south:
    "Watch out for penguins"
case .east:
    "Where the sun rises"
case .west:
    "Where the skies are blue"
}

let somePlanet = Planet.earth
switch somePlanet {
case .earth:
    "Mostly harmless"
default:
    "Not a safe place for humans"
}
// Prints "Mostly harmless"
print("===============================================================")
print("============3.Iterating over Enumeration Cases==========")
print("===============================================================")
enum Beverage: CaseIterable {
    case coffee, tea, juice
}
let numberOfChoices = Beverage.allCases.count
"\(numberOfChoices) beverages available"
// Prints "3 beverages available"
for beverage in Beverage.allCases {
  print(beverage)
}
//// coffee
//// tea
//// juice
print("===============================================================")
print("============4.Associated Values==========")
print("===============================================================")
enum Barcode {
    case upc(Int, Int, Int, Int)
    case qrCode(String)
}

var productBarcode = Barcode.upc(8, 85909, 51226, 3)
productBarcode = .qrCode("ABCDEFGHIJKLMNOP")

switch productBarcode {
case .upc(let numberSystem, let manufacturer, let product, let check):
    "UPC: \(numberSystem), \(manufacturer), \(product), \(check)."
case .qrCode(let productCode):
    "QR code: \(productCode)."
}
// Prints "QR code: ABCDEFGHIJKLMNOP."
//If all of the associated values for an enumeration case are extracted as constants, or if all are extracted as variables, you can place a single let or var annotation before the case name, for brevity:
switch productBarcode {
case let .upc(numberSystem, manufacturer, product, check):
    "UPC : \(numberSystem), \(manufacturer), \(product), \(check)."
case let .qrCode(productCode):
    "QR code: \(productCode)."
}
// Prints "QR code: ABCDEFGHIJKLMNOP."
print("===============================================================")
print("============5.Raw Values==========")
print("===============================================================")
enum ASCIIControlCharacter: Character {
    case tab = "\t"
    case lineFeed = "\n"
    case carriageReturn = "\r"
}
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
print("++++++++++++++++a.Implicitly Assigned Raw Values++++++++++++++")
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
enum PlanetB: Int {
    case mercury = 1, venus, earth, mars, jupiter, saturn, uranus, neptune
}
enum CompassPointB: String {
    case north, south, east, west
}
let earthsOrder = PlanetB.earth.rawValue
earthsOrder
// earthsOrder is 3


let sunsetDirection = CompassPointB.west.rawValue
sunsetDirection
// sunsetDirection is "west"
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
print("++++++++++++++++b.Initializing from a Raw Value++++++++++++++")
print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
let possiblePlanet = PlanetB(rawValue: 7)
// possiblePlanet is of type Planet? and equals Planet.uranus
let positionToFind = 11
if let somePlanet = PlanetB(rawValue: positionToFind) {
    switch somePlanet {
    case .earth:
        "Mostly harmless"
    default:
        "Not a safe place for humans"
    }
} else {
    "There isn't a planet at position \(positionToFind)"
}
// Prints "There isn't a planet at position 11"
print("===============================================================")
print("============6.Recursive Enumerations==========")
print("===============================================================")
enum ArithmeticExpression {
    case number(Int)
    indirect case addition(ArithmeticExpression, ArithmeticExpression)
    indirect case multiplication(ArithmeticExpression, ArithmeticExpression)
}
indirect enum ArithmeticExpressionB {
    case number(Int)
    case addition(ArithmeticExpressionB, ArithmeticExpressionB)
    case multiplication(ArithmeticExpressionB, ArithmeticExpressionB)
}
let five = ArithmeticExpressionB.number(5)
five
let four = ArithmeticExpressionB.number(4)
four
let sum = ArithmeticExpressionB.addition(five, four)
sum
let product = ArithmeticExpressionB.multiplication(sum, ArithmeticExpressionB.number(2))
product
func evaluate(_ expression: ArithmeticExpressionB) -> Int {
    switch expression {
    case let .number(value):
        return value
    case let .addition(left, right):
        return evaluate(left) + evaluate(right)
    case let .multiplication(left, right):
        return evaluate(left) * evaluate(right)
    }
}

evaluate(product)
// Prints "18"
